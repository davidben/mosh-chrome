// Copyright 2011 Google Inc. All Rights Reserved.

/**
 * @fileoverview Defined the convenience function cvox.Msgs.getMsg.
 * @author deboer@google.com (James deBoer)
 */

goog.provide('cvox.Msgs');


/**
 * The namespace for all Chromevox messages.
 * @type {string}
 * @const
 * @private
 */
cvox.Msgs.NAMESPACE_ = 'chromevox_';


cvox.Msgs.STRINGS = {"locale":{"message":"en"},"chromevox_name":{"message":"ChromeVox"},"chromevox_description":{"message":"ChromeVox - Giving Voice to Chrome"},"chromevox_stop_speech_key":{"message":"Stop speaking"},"chromevox_toggle_sticky_mode":{"message":"Enable/Disable sticky mode"},"chromevox_handle_tab_next":{"message":"Jump to next focusable item"},"chromevox_handle_tab_prev":{"message":"Jump to previous focusable item"},"chromevox_backward":{"message":"Navigate backward"},"chromevox_forward":{"message":"Navigate forward"},"chromevox_previous_granularity":{"message":"Decrease navigation granularity"},"chromevox_next_granularity":{"message":"Increase navigation granularity"},"chromevox_act_on_current_item":{"message":"Take action on current item"},"chromevox_force_click_on_current_item":{"message":"Click on current item"},"chromevox_read_link_url":{"message":"Announce the URL behind a link"},"chromevox_read_current_title":{"message":"Announce the title of the current page"},"chromevox_read_current_url":{"message":"Announce the URL of the current page"},"chromevox_read_from_here":{"message":"Start reading from current location"},"chromevox_show_power_key":{"message":"Show ChromeVox help"},"chromevox_hide_power_key":{"message":"Hide ChromeVox help"},"chromevox_help":{"message":"Open ChromeVox help documentation"},"chromevox_toggle_search_widget":{"message":"Toggle search widget"},"chromevox_show_options_page":{"message":"Open options page"},"chromevox_show_kb_explorer_page":{"message":"Open keyboard explorer"},"chromevox_decrease_tts_rate":{"message":"Decrease rate of speech"},"chromevox_increase_tts_rate":{"message":"Increase rate of speech"},"chromevox_decrease_tts_pitch":{"message":"Decrease pitch"},"chromevox_increase_tts_pitch":{"message":"Increase pitch"},"chromevox_decrease_tts_volume":{"message":"Decrease speech volume"},"chromevox_increase_tts_volume":{"message":"Increase speech volume"},"chromevox_show_lens":{"message":"Show lens"},"chromevox_hide_lens":{"message":"Hide lens"},"chromevox_toggle_lens":{"message":"Toggle lens"},"chromevox_anchor_lens":{"message":"Anchor lens at top"},"chromevox_float_lens":{"message":"Float lens near text"},"chromevox_show_forms_list":{"message":"Show forms list"},"chromevox_show_headings_list":{"message":"Show headings list"},"chromevox_show_jumps_list":{"message":"Show jumps list"},"chromevox_show_links_list":{"message":"Show links list"},"chromevox_show_tables_list":{"message":"Show tables list"},"chromevox_show_landmarks_list":{"message":"Show landmarks list"},"chromevox_toggle_table":{"message":"Toggle table mode"},"chromevox_previous_row":{"message":"Previous table row"},"chromevox_next_row":{"message":"Next table row"},"chromevox_previous_col":{"message":"Previous table column"},"chromevox_next_col":{"message":"Next table column"},"chromevox_announce_headers":{"message":"Announce the headers of the current cell"},"chromevox_speak_table_location":{"message":"Announce the current table location"},"chromevox_guess_row_header":{"message":"Make a guess at the row header of the current cell"},"chromevox_guess_col_header":{"message":"Make a guess at the column header of the current cell"},"chromevox_skip_to_beginning":{"message":"Go to beginning of table"},"chromevox_skip_to_end":{"message":"Go to end of table"},"chromevox_skip_to_row_beginning":{"message":"Go to beginning of the current row"},"chromevox_skip_to_row_end":{"message":"Go to end of the current row"},"chromevox_skip_to_col_beginning":{"message":"Go to beginning of the current column"},"chromevox_skip_to_col_end":{"message":"Go to end of the current column"},"chromevox_next_heading1":{"message":"Next level 1 heading"},"chromevox_previous_heading1":{"message":"Previous level 1 heading"},"chromevox_next_heading2":{"message":"Next level 2 heading"},"chromevox_previous_heading2":{"message":"Previous level 2 heading"},"chromevox_next_heading3":{"message":"Next level 3 heading"},"chromevox_previous_heading3":{"message":"Previous level 3 heading"},"chromevox_next_heading4":{"message":"Next level 4 heading"},"chromevox_previous_heading4":{"message":"Previous level 4 heading"},"chromevox_next_heading5":{"message":"Next level 5 heading"},"chromevox_previous_heading5":{"message":"Previous level 5 heading"},"chromevox_next_heading6":{"message":"Next level 6 heading"},"chromevox_previous_heading6":{"message":"Previous level 6 heading"},"chromevox_next_anchor":{"message":"Next anchor"},"chromevox_previous_anchor":{"message":"Previous anchor"},"chromevox_next_combo_box":{"message":"Next combo box"},"chromevox_previous_combo_box":{"message":"Previous combo box"},"chromevox_next_edit_text":{"message":"Next editable text area"},"chromevox_previous_edit_text":{"message":"Previous editable text area"},"chromevox_next_form_field":{"message":"Next form field"},"chromevox_previous_form_field":{"message":"Previous form field"},"chromevox_next_graphic":{"message":"Next graphic"},"chromevox_previous_graphic":{"message":"Previous graphic"},"chromevox_next_heading":{"message":"Next heading"},"chromevox_previous_heading":{"message":"Previous heading"},"chromevox_next_list_item":{"message":"Next list item"},"chromevox_previous_list_item":{"message":"Previous list item"},"chromevox_next_jump":{"message":"Next jump"},"chromevox_previous_jump":{"message":"Previous jump"},"chromevox_next_link":{"message":"Next link"},"chromevox_previous_link":{"message":"Previous link"},"chromevox_next_list":{"message":"Next list"},"chromevox_previous_list":{"message":"Previous list"},"chromevox_next_blockquote":{"message":"Next block quote"},"chromevox_previous_blockquote":{"message":"Previous block quote"},"chromevox_next_radio":{"message":"Next radio button"},"chromevox_previous_radio":{"message":"Previous radio button"},"chromevox_next_slider":{"message":"Next slider"},"chromevox_previous_slider":{"message":"Previous slider"},"chromevox_next_table":{"message":"Next table"},"chromevox_previous_table":{"message":"Previous table"},"chromevox_next_button":{"message":"Next button"},"chromevox_previous_button":{"message":"Previous button"},"chromevox_next_checkbox":{"message":"Next checkbox"},"chromevox_previous_checkbox":{"message":"Previous checkbox"},"chromevox_next_landmark":{"message":"Next landmark"},"chromevox_previous_landmark":{"message":"Previous landmark"},"chromevox_benchmark":{"message":"Debug benchmark"},"chromevox_options_page_title":{"message":"ChromeVox Options"},"chromevox_options_page_summary":{"message":"Use the options below to customize ChromeVox. Changes take effect immediately."},"chromevox_options_magnifier":{"message":"Magnifier"},"chromevox_options_magnifier_show_checkbox":{"message":"Show Magnifier"},"chromevox_options_magnifier_top_of_page":{"message":"At top of page"},"chromevox_options_magnifier_next_focused":{"message":"Next to focused element"},"chromevox_options_mouse":{"message":"Mouse"},"chromevox_options_mouse_focus_follows":{"message":"Focus follows mouse"},"chromevox_options_verbosity":{"message":"Verbosity"},"chromevox_options_verbosity_verbose":{"message":"Verbose"},"chromevox_options_verbosity_brief":{"message":"Brief"},"chromevox_options_cursor":{"message":"When editing text"},"chromevox_options_cursor_between_characters":{"message":"The cursor is between characters (like on Mac OS X)"},"chromevox_options_cursor_on_character":{"message":"The cursor is on a character (like on Windows)"},"chromevox_options_key_assignments":{"message":"Key assignments"},"chromevox_options_reset_keys":{"message":"Reset to default keys"},"chromevox_kbexplorer_title":{"message":"ChromeOS Keyboard Explorer"},"chromevox_kbexplorer_instructions":{"message":"Press any key to learn its name. Ctrl+W will close the keyboard explorer."},"chromevox_chrome_tab_created":{"message":"$1, tab created.","placeholders":{"1":{"content":"$1"}}},"chromevox_chrome_tab_selected":{"message":"$1, tab.","placeholders":{"1":{"content":"$1"}}},"chromevox_chrome_normal_window_selected":{"message":"window, $1, tab.","placeholders":{"1":{"content":"$1"}}},"chromevox_chrome_incognito_window_selected":{"message":"incognito window, $1, tab.","placeholders":{"1":{"content":"$1"}}},"chromevox_chrome_menu_opened":{"message":"$1, menu opened.","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_checkbox_checked":{"message":"$1, checkbox checked","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_checkbox_unchecked":{"message":"$1, checkbox not checked","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_radio_selected":{"message":"$1, radio button selected","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_radio_unselected":{"message":"$1, radio button unselected","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_menu":{"message":"$1, menu","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_menu_item":{"message":"$1, menu item","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_menu_item_with_submenu":{"message":"$1, menu item, with submenu","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_window":{"message":"$1, window","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_textbox":{"message":"$1, $2, text box","placeholders":{"1":{"content":"$1"},"2":{"content":"$2"}}},"chromevox_describe_unnamed_textbox":{"message":"$1, text box","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_password":{"message":"$1, $2, password text box","placeholders":{"1":{"content":"$1"},"2":{"content":"$2"}}},"chromevox_describe_unnamed_password":{"message":"$1, password text box","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_button":{"message":"$1, button","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_combobox":{"message":"$1, $2, combo box","placeholders":{"1":{"content":"$1"},"2":{"content":"$2"}}},"chromevox_describe_unnamed_combobox":{"message":"$1, combo box","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_listbox":{"message":"$1, $2, list box","placeholders":{"1":{"content":"$1"},"2":{"content":"$2"}}},"chromevox_describe_unnamed_listbox":{"message":"$1, list box","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_link":{"message":"$1, link","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_tab":{"message":"$1, tab","placeholders":{"1":{"content":"$1"}}},"chromevox_describe_selected":{"message":", selected"},"chromevox_describe_index":{"message":", $1 of $2, ","placeholders":{"1":{"content":"$1"},"2":{"content":"$2"}}}};


/**
 * Returns the message with the given message id from the ChromeVox namespace.
 *
 * If we can't find a message, throw an exception.  This allows us to catch
 * typos early.
 *
 * @param {string} message_id The id.
 * @param {Array.<string>} opt_subs Substitution strings.
 * @return {string} The message.
 */
cvox.Msgs.getMsg = function(message_id, opt_subs) {
  var template = cvox.Msgs.STRINGS['chromevox_' + message_id]['message'];
  var message = template;
  if (opt_subs) {
    for (var i = 0; i < opt_subs.length; i++) {
      var src = '$' + (i + 1);
      var dst = opt_subs[i];
      message = message.replace(src, dst);
    }
  }

  if (message == undefined || message == '') {
    throw new Error('Invalid ChromeVox message id: ' + message_id);
  }
  return message;
};


/**
 * Processes an HTML DOM the text of "i18n" elements with translated messages.
 * This function expects HTML elements with a i18n clean and a msgid attribute.
 *
 * @param {Node} root The root node where the translation should be performed.
 */
cvox.Msgs.addTranslatedMessagesToDom = function(root) {
  var elts = root.querySelectorAll('.i18n');
  for (var i = 0; i < elts.length; i++) {
    elts[i].textContent = cvox.Msgs.getMsg(elts[i].getAttribute('msgid'));
  }
};
