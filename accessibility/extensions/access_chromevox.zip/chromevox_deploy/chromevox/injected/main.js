// Copyright (c) 2011 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/**
 * @fileoverview The main entry point for the extension content script.
 *
 * This is the only file that has access to the chrome.extension API
 * from the content script, because all other scripts are loaded into the
 * document head. So, any use of these extension APIs must be done in this
 * file.
 */

// TODO(dmazzoni): pull in these dependencies without explicitly
// calling the private method writeScriptTag_.
function initialize() {
  if (COMPILED) {
    var loadCompiledScript = function(scriptRelPath) {
      var scriptElt = document.createElement('script');
      scriptElt.type = 'text/javascript';
      scriptElt.src = chrome.extension.getURL(scriptRelPath);
      document.getElementsByTagName('head')[0].appendChild(scriptElt);
    };
    if (BUILD_TYPE == BUILD_TYPE_CHROME) {
      if (window.location.toString().indexOf('chrome-extension://') == -1 ||
          window.location.toString().indexOf('background.html') == -1) {
        loadCompiledScript('/chromeVoxChromePageScript.js');
      }
    } else if (BUILD_TYPE == BUILD_TYPE_ANDROID_DEV) {
      loadCompiledScript('/androidVoxDev.js');
    } else {
      throw 'Unknown or unsupported build type: ' + BUILD_TYPE;
    }
  } else {
    goog.writeScriptTag_(chrome.extension.getURL('/closure/base.js'));
    goog.writeScriptTag_(chrome.extension.getURL('../powerkey-bundle.js'));
    goog.require('cvox.ChromeVoxInit');
  }
}

initialize();
