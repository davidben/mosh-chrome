// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @fileoverview Script for ChromeOS keyboard explorer.
 *
 * @author chaitanyag@google.com (Chaitanya Gharpure)
 */

function cvoxKbExplorerInit() {
  document.addEventListener('keydown', onKeyDown, false);
  document.addEventListener('keyup', onKeyUp, false);
  document.addEventListener('keypress', onKeyPress, false);
}

function onKeyDown(evt) {
  var str = '';
  if (evt.keyCode == 0) {
    str = 'Power button';
  } else if (evt.keyCode == 17) {
    str = 'Control';
  } else if (evt.keyCode == 18) {
    str = 'Alt';
  } else if (evt.keyCode == 16) {
    str = 'Shift';
  } else if (evt.keyCode == 9) {
    str = 'Tab';
  } else if (evt.keyCode == 91) {
    str = 'Search';
  } else if (evt.keyCode == 8) {
    str = 'Backspace';
  } else if (evt.keyCode == 32) {
    str = 'Space';
  } else if (evt.keyCode == 37) {
    str = 'Left arrow';
  } else if (evt.keyCode == 38) {
    str = 'Up arrow';
  } else if (evt.keyCode == 39) {
    str = 'Right arrow';
  } else if (evt.keyCode == 40) {
    str = 'Down arrow';
  } else if (evt.keyCode == 13) {
    str = 'Enter';
  } else if (evt.keyCode == 27) {
    str = 'Escape';
  } else if (evt.keyCode == 112) {
    str = 'Back';
  } else if (evt.keyCode == 113) {
    str = 'Forward';
  } else if (evt.keyCode == 114) {
    str = 'Refresh';
  } else if (evt.keyCode == 115) {
    str = 'Toggle full screen';
  } else if (evt.keyCode == 186) {
    str = 'Semicolon';
  } else if (evt.keyCode == 187) {
    str = 'Equal sign';
  } else if (evt.keyCode == 188) {
    str = 'Comma';
  } else if (evt.keyCode == 189) {
    str = 'Dash';
  } else if (evt.keyCode == 190) {
    str = 'Period';
  } else if (evt.keyCode == 191) {
    str = 'Forward slash';
  } else if (evt.keyCode == 192) {
    str = 'Grave accent';
  } else if (evt.keyCode == 219) {
    str = 'Open bracket';
  } else if (evt.keyCode == 220) {
    str = 'Back slash';
  } else if (evt.keyCode == 221) {
    str = 'Close bracket';
  } else if (evt.keyCode == 222) {
    str = 'Single quote';
  } else if (evt.keyCode == 115) {
    str = 'Toggle full screen';
  } else if (evt.keyCode >=48 && evt.keyCode <= 90){
    str = String.fromCharCode(evt.keyCode);
  }
  chrome.extension.getBackgroundPage().background.ttsManager.speak(
      str, false, null);
  evt.preventDefault();
  evt.stopPropagation();
}

function onKeyUp(evt) {
  evt.preventDefault();
  evt.stopPropagation();
}

function onKeyPress(evt) {
  evt.preventDefault();
  evt.stopPropagation();
}

cvoxKbExplorerInit();
